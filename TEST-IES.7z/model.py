with open("params.txt") as f:
    a = float(f.readline())
    b = float(f.readline())

result = (a - 2)**2 + (b-3)**2

with open("output.txt", "w") as f:
    f.write(f"{result:.4f}\n")


